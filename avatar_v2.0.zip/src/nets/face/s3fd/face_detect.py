#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
# @FileName      : face_detect.py
# @Time          : 2026-06-23 22:57:24
# @Author        : XuMing
# @Email         : 920972751@qq.com
# @description   : 人脸检测器抽象基类
# @Company       : 2026 XuMing. All Rights Reserved.
"""

import glob
import logging

import cv2
import numpy as np
import torch
from tqdm import tqdm


class FaceDetector(object):
    """人脸检测器基类。

    子类需要实现 detect_from_image，并返回检测框列表。
    """

    def __init__(self, device, verbose):
        self.device = device
        self.verbose = verbose

        device_str = str(device)

        if verbose and "cpu" in device_str:
            logging.getLogger(__name__).warning(
                "Detection running on CPU, this may be potentially slow."
            )

        if "cpu" not in device_str and "cuda" not in device_str:
            if verbose:
                logging.getLogger(__name__).error(
                    "Expected values for device are: {cpu, cuda} but got: %s",
                    device_str,
                )
            raise ValueError

    def detect_from_image(self, tensor_or_path):
        """检测单张图片中的人脸。"""
        raise NotImplementedError

    def detect_from_directory(
        self,
        path,
        extensions=[".jpg", ".png"],
        recursive=False,
        show_progress_bar=True,
    ):
        """检测目录中的图片。"""
        logger = logging.getLogger(__name__) if self.verbose else None

        if len(extensions) == 0:
            if self.verbose:
                logger.error("Expected at list one extension, but none was received.")
            raise ValueError

        if self.verbose:
            logger.info("Constructing the list of images.")

        additional_pattern = "/**/*" if recursive else "/*"
        files = []

        for extension in extensions:
            files.extend(
                glob.glob(path + additional_pattern + extension, recursive=recursive)
            )

        if self.verbose:
            logger.info("Finished searching for images. %s images found", len(files))
            logger.info("Preparing to run the detection.")

        predictions = {}
        for image_path in tqdm(files, disable=not show_progress_bar):
            if self.verbose:
                logger.info("Running the face detector on image: %s", image_path)
            predictions[image_path] = self.detect_from_image(image_path)

        if self.verbose:
            logger.info("The detector was successfully run on all %s images", len(files))

        return predictions

    @property
    def reference_scale(self):
        raise NotImplementedError

    @property
    def reference_x_shift(self):
        raise NotImplementedError

    @property
    def reference_y_shift(self):
        raise NotImplementedError

    @staticmethod
    def tensor_or_path_to_ndarray(tensor_or_path, rgb=True):
        """将路径、torch.Tensor 或 numpy.ndarray 转为 numpy.ndarray。

        参数:
            tensor_or_path:
                图片路径、图片数组或 Tensor。
            rgb:
                保持原接口默认值。True 时将 cv2 读取的 BGR 转为 RGB；
                False 时保留 BGR。

        返回:
            numpy.ndarray 图片数组。
        """
        if isinstance(tensor_or_path, str):
            img = cv2.imread(tensor_or_path)
            if img is None:
                raise FileNotFoundError(f"Image not found or unreadable: {tensor_or_path}")
            return img if not rgb else img[..., ::-1]

        if torch.is_tensor(tensor_or_path):
            arr = tensor_or_path.detach().cpu().numpy()
            return arr[..., ::-1].copy() if not rgb else arr

        if isinstance(tensor_or_path, np.ndarray):
            return tensor_or_path[..., ::-1].copy() if not rgb else tensor_or_path

        raise TypeError(f"Unsupported input type: {type(tensor_or_path)}")
